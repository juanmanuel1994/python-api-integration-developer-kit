# -*- coding: utf-8 -*-
"""
Test simulado del GitHub Dashboard — sin token ni conexion real.
Usa 'responses' para interceptar las llamadas HTTP y devolver datos falsos.
"""

import sys
import io
import subprocess

if sys.platform == "win32":
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

# Auto-instalar dependencias de test
for pkg in ("responses", "flask"):
    try:
        __import__(pkg)
    except ImportError:
        print(f"  Instalando {pkg}...")
        subprocess.check_call([sys.executable, "-m", "pip", "install", pkg, "-q"])

import json
import responses as resp_lib
import requests
from datetime import datetime, timedelta

# ---------------------------------------------------------------------------
# Datos simulados
# ---------------------------------------------------------------------------

OWNER = "mi-empresa"
REPO  = "mi-proyecto"
BASE  = "https://api.github.com"

REPOS_FALSOS = [
    {"id": 1, "name": "mi-proyecto",        "full_name": f"{OWNER}/mi-proyecto",        "description": "Proyecto principal",          "stargazers_count": 42,  "forks_count": 8,  "open_issues_count": 5,  "language": "Python",     "updated_at": "2024-06-01T10:00:00Z"},
    {"id": 2, "name": "api-backend",         "full_name": f"{OWNER}/api-backend",         "description": "API REST con FastAPI",         "stargazers_count": 17,  "forks_count": 3,  "open_issues_count": 2,  "language": "Python",     "updated_at": "2024-05-28T09:00:00Z"},
    {"id": 3, "name": "dashboard-frontend",  "full_name": f"{OWNER}/dashboard-frontend",  "description": "Frontend en React",           "stargazers_count": 9,   "forks_count": 1,  "open_issues_count": 1,  "language": "TypeScript", "updated_at": "2024-05-20T08:00:00Z"},
]

ISSUES_FALSOS = [
    {"number": 12, "title": "Error al exportar CSV con caracteres especiales", "user": {"login": "ana_dev"},   "created_at": "2024-05-30T08:00:00Z", "updated_at": "2024-06-01T10:00:00Z", "labels": [{"name": "bug"}],         "comments": 3, "html_url": f"https://github.com/{OWNER}/{REPO}/issues/12"},
    {"number": 11, "title": "Agregar filtro por fecha en el dashboard",         "user": {"login": "carlos_pm"}, "created_at": "2024-05-25T14:00:00Z", "updated_at": "2024-05-29T09:00:00Z", "labels": [{"name": "enhancement"}], "comments": 1, "html_url": f"https://github.com/{OWNER}/{REPO}/issues/11"},
    {"number": 10, "title": "Mejorar rendimiento de la query de commits",       "user": {"login": "luis_be"},   "created_at": "2024-05-20T11:00:00Z", "updated_at": "2024-05-27T16:00:00Z", "labels": [{"name": "performance"}], "comments": 5, "html_url": f"https://github.com/{OWNER}/{REPO}/issues/10"},
    {"number":  9, "title": "Documentar endpoints de la API",                   "user": {"login": "sofia_doc"}, "created_at": "2024-05-15T09:00:00Z", "updated_at": "2024-05-22T10:00:00Z", "labels": [{"name": "docs"}],        "comments": 0, "html_url": f"https://github.com/{OWNER}/{REPO}/issues/9"},
]

PULLS_FALSOS_OPEN = [
    {"number": 25, "title": "feat: nueva vista de metricas por autor",  "user": {"login": "ana_dev"},   "created_at": "2024-06-01T07:00:00Z", "updated_at": "2024-06-01T12:00:00Z", "state": "open",   "draft": False, "additions": 312, "deletions": 45,  "changed_files": 6,  "html_url": f"https://github.com/{OWNER}/{REPO}/pull/25"},
    {"number": 24, "title": "fix: corregir paginacion en gh_get_paginated", "user": {"login": "luis_be"},  "created_at": "2024-05-31T15:00:00Z", "updated_at": "2024-06-01T09:00:00Z", "state": "open",   "draft": True,  "additions": 28,  "deletions": 12,  "changed_files": 2,  "html_url": f"https://github.com/{OWNER}/{REPO}/pull/24"},
]

PULLS_FALSOS_CLOSED = [
    {"number": 23, "title": "refactor: separar helpers de rutas Flask",   "user": {"login": "carlos_pm"}, "created_at": "2024-05-28T10:00:00Z", "updated_at": "2024-05-30T17:00:00Z", "state": "closed", "draft": False, "additions": 198, "deletions": 201, "changed_files": 8,  "html_url": f"https://github.com/{OWNER}/{REPO}/pull/23"},
    {"number": 22, "title": "chore: actualizar dependencias mayo 2024",   "user": {"login": "luis_be"},   "created_at": "2024-05-22T09:00:00Z", "updated_at": "2024-05-23T11:00:00Z", "state": "closed", "draft": False, "additions": 5,   "deletions": 5,   "changed_files": 1,  "html_url": f"https://github.com/{OWNER}/{REPO}/pull/22"},
    {"number": 21, "title": "feat: exportacion CSV de commits",           "user": {"login": "ana_dev"},   "created_at": "2024-05-18T14:00:00Z", "updated_at": "2024-05-20T10:00:00Z", "state": "closed", "draft": False, "additions": 88,  "deletions": 10,  "changed_files": 3,  "html_url": f"https://github.com/{OWNER}/{REPO}/pull/21"},
]

def _make_commits():
    autores = ["ana_dev", "luis_be", "carlos_pm", "sofia_doc"]
    commits = []
    base_date = datetime(2024, 6, 1)
    shas = [
        "a1b2c3d", "e4f5g6h", "i7j8k9l", "m0n1o2p", "q3r4s5t",
        "u6v7w8x", "y9z0a1b", "c2d3e4f", "g5h6i7j", "k8l9m0n",
        "o1p2q3r", "s4t5u6v", "w7x8y9z", "a0b1c2d", "e3f4g5h",
    ]
    messages = [
        "feat: agregar grafico de commits por autor",
        "fix: corregir calculo de metricas en get_metrics",
        "docs: actualizar README con instrucciones de setup",
        "refactor: simplificar gh_get_paginated",
        "test: agregar tests simulados con responses",
        "feat: exportar issues a CSV",
        "fix: manejar repositorios sin commits",
        "chore: actualizar requirements.txt",
        "feat: filtro por rango de fechas",
        "fix: error 404 cuando owner no existe",
        "feat: mostrar draft PRs en tabla",
        "docs: agregar ejemplos de uso en README",
        "refactor: mover helpers a utils.py",
        "fix: encoding UTF-8 en exportacion CSV",
        "feat: KPI cards en el dashboard",
    ]
    for i, sha in enumerate(shas):
        delta = timedelta(days=i // 2, hours=i * 3 % 24)
        date  = (base_date - delta).strftime("%Y-%m-%dT%H:%M:%SZ")
        autor = autores[i % len(autores)]
        commits.append({
            "sha": sha + "0000",
            "commit": {
                "message": messages[i % len(messages)],
                "author":  {"name": autor, "date": date},
            },
            "author":   {"login": autor},
            "html_url": f"https://github.com/{OWNER}/{REPO}/commit/{sha}",
        })
    return commits

COMMITS_FALSOS = _make_commits()

REPO_INFO_FALSO = {
    "name":              REPO,
    "full_name":         f"{OWNER}/{REPO}",
    "description":       "Proyecto principal de la empresa",
    "stargazers_count":  42,
    "forks_count":       8,
    "open_issues_count": 5,
    "language":          "Python",
    "updated_at":        "2024-06-01T10:00:00Z",
}

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

VERDE   = "\033[92m"
ROJO    = "\033[91m"
AMARILLO = "\033[93m"
CYAN    = "\033[96m"
BLANCO  = "\033[97m"
RESET   = "\033[0m"
NEGRITA = "\033[1m"

def ok(msg):   print(f"  {VERDE}[PASS]{RESET} {msg}")
def fail(msg): print(f"  {ROJO}[FAIL]{RESET} {msg}"); sys.exit(1)
def titulo(msg): print(f"\n{NEGRITA}{CYAN}{'='*55}{RESET}\n{NEGRITA}{CYAN}  {msg}{RESET}\n{NEGRITA}{CYAN}{'='*55}{RESET}")
def seccion(msg): print(f"\n{AMARILLO}{NEGRITA}-- {msg} --{RESET}")

# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

@resp_lib.activate
def test_repos():
    seccion("1. Listar repositorios (org)")
    resp_lib.add(resp_lib.GET, f"{BASE}/orgs/{OWNER}/repos",
                 json=REPOS_FALSOS, status=200)

    r = requests.get(f"{BASE}/orgs/{OWNER}/repos")
    assert r.status_code == 200, f"Status inesperado: {r.status_code}"
    data = r.json()
    assert len(data) == 3, f"Se esperaban 3 repos, llegaron {len(data)}"

    ok(f"Se encontraron {len(data)} repositorios simulados:")
    for repo in data:
        print(f"      {BLANCO}* {repo['name']}{RESET}  ({repo['language']})  "
              f"[stars={repo['stargazers_count']}  issues={repo['open_issues_count']}]")


@resp_lib.activate
def test_issues():
    seccion("2. Issues abiertos")
    resp_lib.add(resp_lib.GET, f"{BASE}/repos/{OWNER}/{REPO}/issues",
                 json=ISSUES_FALSOS, status=200)

    r = requests.get(f"{BASE}/repos/{OWNER}/{REPO}/issues",
                     params={"state": "open"})
    assert r.status_code == 200
    data = r.json()
    assert len(data) == 4

    ok(f"Se encontraron {len(data)} issues abiertos:")
    for i in data:
        etiquetas = ", ".join(lb["name"] for lb in i.get("labels", []))
        print(f"      #{i['number']:>3}  {BLANCO}{i['title'][:50]}{RESET}  "
              f"[{AMARILLO}{etiquetas}{RESET}]  comentarios={i['comments']}")


@resp_lib.activate
def test_pulls():
    seccion("3. Pull Requests (open + closed)")
    resp_lib.add(resp_lib.GET, f"{BASE}/repos/{OWNER}/{REPO}/pulls",
                 json=PULLS_FALSOS_OPEN, status=200,
                 match_querystring=False)

    r = requests.get(f"{BASE}/repos/{OWNER}/{REPO}/pulls",
                     params={"state": "open"})
    assert r.status_code == 200
    abiertos = r.json()
    assert len(abiertos) == 2

    ok(f"PRs abiertos: {len(abiertos)}")
    for p in abiertos:
        draft = " [DRAFT]" if p["draft"] else ""
        print(f"      #{p['number']}  {BLANCO}{p['title'][:50]}{RESET}{AMARILLO}{draft}{RESET}")

    resp_lib.add(resp_lib.GET, f"{BASE}/repos/{OWNER}/{REPO}/pulls",
                 json=PULLS_FALSOS_CLOSED, status=200,
                 match_querystring=False)

    r2 = requests.get(f"{BASE}/repos/{OWNER}/{REPO}/pulls",
                      params={"state": "closed"})
    cerrados = r2.json()
    assert len(cerrados) == 3

    ok(f"PRs cerrados: {len(cerrados)}")
    for p in cerrados:
        print(f"      #{p['number']}  {BLANCO}{p['title'][:50]}{RESET}  "
              f"+{p['additions']}/-{p['deletions']} en {p['changed_files']} archivos")


@resp_lib.activate
def test_commits():
    seccion("4. Commits recientes")
    resp_lib.add(resp_lib.GET, f"{BASE}/repos/{OWNER}/{REPO}/commits",
                 json=COMMITS_FALSOS, status=200)

    r = requests.get(f"{BASE}/repos/{OWNER}/{REPO}/commits")
    assert r.status_code == 200
    data = r.json()
    assert len(data) == 15

    ok(f"Se encontraron {len(data)} commits simulados:")
    for c in data[:5]:
        sha    = c["sha"][:7]
        msg    = c["commit"]["message"][:50]
        autor  = c["commit"]["author"]["name"]
        fecha  = c["commit"]["author"]["date"][:10]
        print(f"      {CYAN}{sha}{RESET}  {BLANCO}{msg}{RESET}  "
              f"— {autor}  ({fecha})")
    if len(data) > 5:
        print(f"      ... y {len(data)-5} commits mas")


@resp_lib.activate
def test_metricas():
    seccion("5. Metricas del repositorio")

    # commits
    resp_lib.add(resp_lib.GET, f"{BASE}/repos/{OWNER}/{REPO}/commits",
                 json=COMMITS_FALSOS, status=200)
    # repo info para open_issues_count
    resp_lib.add(resp_lib.GET, f"{BASE}/repos/{OWNER}/{REPO}",
                 json=REPO_INFO_FALSO, status=200)
    # open PRs
    resp_lib.add(resp_lib.GET, f"{BASE}/repos/{OWNER}/{REPO}/pulls",
                 json=PULLS_FALSOS_OPEN, status=200,
                 match_querystring=False)
    # closed PRs (segunda llamada al mismo endpoint)
    resp_lib.add(resp_lib.GET, f"{BASE}/repos/{OWNER}/{REPO}/pulls",
                 json=PULLS_FALSOS_CLOSED, status=200,
                 match_querystring=False)

    # Simular la logica de get_metrics directamente
    commits     = COMMITS_FALSOS
    repo_info   = REPO_INFO_FALSO
    open_prs    = PULLS_FALSOS_OPEN
    closed_prs  = PULLS_FALSOS_CLOSED

    from collections import defaultdict
    commits_by_author = defaultdict(int)
    for c in commits:
        autor = (c.get("author") or {}).get("login") or c["commit"]["author"]["name"]
        commits_by_author[autor] += 1

    metricas = {
        "total_commits":       len(commits),
        "total_open_issues":   repo_info["open_issues_count"],
        "open_prs":            len(open_prs),
        "closed_prs":          len(closed_prs),
        "active_contributors": len(commits_by_author),
    }

    assert metricas["total_commits"]       == 15
    assert metricas["total_open_issues"]   == 5
    assert metricas["open_prs"]            == 2
    assert metricas["closed_prs"]          == 3
    assert metricas["active_contributors"] == 4

    ok("Metricas calculadas correctamente:")
    print(f"      Total commits       : {BLANCO}{metricas['total_commits']}{RESET}")
    print(f"      Issues abiertos     : {BLANCO}{metricas['total_open_issues']}{RESET}")
    print(f"      PRs abiertos        : {BLANCO}{metricas['open_prs']}{RESET}")
    print(f"      PRs cerrados        : {BLANCO}{metricas['closed_prs']}{RESET}")
    print(f"      Contribuidores activos : {BLANCO}{metricas['active_contributors']}{RESET}")

    ok("Commits por autor:")
    for autor, n in sorted(commits_by_author.items(), key=lambda x: -x[1]):
        barra = VERDE + "█" * n + RESET
        print(f"      {BLANCO}{autor:<15}{RESET}  {barra}  {n}")


@resp_lib.activate
def test_error_404():
    seccion("6. Manejo de error 404 (repo inexistente)")
    resp_lib.add(resp_lib.GET, f"{BASE}/repos/{OWNER}/repo-que-no-existe/issues",
                 json={"message": "Not Found"}, status=404)

    r = requests.get(f"{BASE}/repos/{OWNER}/repo-que-no-existe/issues")
    assert r.status_code == 404
    assert r.json()["message"] == "Not Found"
    ok("Error 404 devuelto y capturado correctamente")


@resp_lib.activate
def test_repo_sin_commits():
    seccion("7. Repositorio sin commits (lista vacia)")
    resp_lib.add(resp_lib.GET, f"{BASE}/repos/{OWNER}/repo-vacio/commits",
                 json=[], status=200)

    r = requests.get(f"{BASE}/repos/{OWNER}/repo-vacio/commits")
    assert r.status_code == 200
    assert r.json() == []
    ok("Lista vacia manejada correctamente — el dashboard mostraria 0 commits")


# ---------------------------------------------------------------------------
# Runner
# ---------------------------------------------------------------------------

def main():
    titulo("GitHub Dashboard — Tests Simulados (sin API real)")
    print(f"  {AMARILLO}Repositorio simulado:{RESET} {OWNER}/{REPO}")
    print(f"  {AMARILLO}Token real necesario:{RESET}  NO")
    print(f"  {AMARILLO}Conexion a internet:{RESET}   NO")

    tests = [
        ("Listar repositorios",   test_repos),
        ("Issues abiertos",       test_issues),
        ("Pull Requests",         test_pulls),
        ("Commits recientes",     test_commits),
        ("Metricas",              test_metricas),
        ("Error 404",             test_error_404),
        ("Repo sin commits",      test_repo_sin_commits),
    ]

    pasados = 0
    for nombre, fn in tests:
        try:
            fn()
            pasados += 1
        except Exception as e:
            print(f"  {ROJO}[FAIL]{RESET} {nombre}: {e}")

    print(f"\n{NEGRITA}{CYAN}{'='*55}{RESET}")
    color = VERDE if pasados == len(tests) else ROJO
    print(f"  {color}{NEGRITA}Resultado: {pasados}/{len(tests)} tests pasados{RESET}")
    print(f"{NEGRITA}{CYAN}{'='*55}{RESET}\n")

    if pasados == len(tests):
        print(f"  {VERDE}Todo OK. El dashboard funcionaria correctamente con datos reales.{RESET}\n")


if __name__ == "__main__":
    main()
