import os
import csv
import io
from datetime import datetime, timedelta
from collections import defaultdict
from flask import Flask, render_template, jsonify, request, Response
from dotenv import load_dotenv
import requests

load_dotenv()

app = Flask(__name__)

GITHUB_TOKEN = os.getenv("GITHUB_TOKEN")
GITHUB_API = "https://api.github.com"

def github_headers():
    return {
        "Authorization": f"token {GITHUB_TOKEN}",
        "Accept": "application/vnd.github.v3+json",
    }

def gh_get(path, params=None):
    url = f"{GITHUB_API}{path}"
    resp = requests.get(url, headers=github_headers(), params=params, timeout=15)
    resp.raise_for_status()
    return resp.json()

def gh_get_paginated(path, params=None, max_pages=5):
    params = params or {}
    params.setdefault("per_page", 100)
    items = []
    for page in range(1, max_pages + 1):
        params["page"] = page
        url = f"{GITHUB_API}{path}"
        resp = requests.get(url, headers=github_headers(), params=params, timeout=15)
        resp.raise_for_status()
        data = resp.json()
        if not data:
            break
        items.extend(data)
        if len(data) < params["per_page"]:
            break
    return items


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/repos")
def get_repos():
    owner = request.args.get("owner", "")
    if not owner:
        return jsonify({"error": "owner parameter required"}), 400
    try:
        # Try as org first, fall back to user
        try:
            repos = gh_get_paginated(f"/orgs/{owner}/repos", {"sort": "updated", "type": "all"})
        except requests.HTTPError:
            repos = gh_get_paginated(f"/users/{owner}/repos", {"sort": "updated"})
        result = [
            {
                "name": r["name"],
                "full_name": r["full_name"],
                "description": r.get("description", ""),
                "stars": r["stargazers_count"],
                "forks": r["forks_count"],
                "open_issues": r["open_issues_count"],
                "language": r.get("language", ""),
                "updated_at": r["updated_at"],
            }
            for r in repos
        ]
        return jsonify(result)
    except requests.HTTPError as e:
        return jsonify({"error": str(e)}), e.response.status_code


@app.route("/api/issues")
def get_issues():
    owner = request.args.get("owner", "")
    repo = request.args.get("repo", "")
    if not owner or not repo:
        return jsonify({"error": "owner and repo parameters required"}), 400
    try:
        issues = gh_get_paginated(
            f"/repos/{owner}/{repo}/issues",
            {"state": "open", "sort": "created", "direction": "desc"},
        )
        # GitHub returns PRs in the issues endpoint; filter them out
        result = [
            {
                "number": i["number"],
                "title": i["title"],
                "user": i["user"]["login"],
                "created_at": i["created_at"],
                "updated_at": i["updated_at"],
                "labels": [lb["name"] for lb in i.get("labels", [])],
                "comments": i["comments"],
                "url": i["html_url"],
            }
            for i in issues
            if "pull_request" not in i
        ]
        return jsonify(result)
    except requests.HTTPError as e:
        return jsonify({"error": str(e)}), e.response.status_code


@app.route("/api/pulls")
def get_pulls():
    owner = request.args.get("owner", "")
    repo = request.args.get("repo", "")
    state = request.args.get("state", "open")
    if not owner or not repo:
        return jsonify({"error": "owner and repo parameters required"}), 400
    try:
        pulls = gh_get_paginated(
            f"/repos/{owner}/{repo}/pulls",
            {"state": state, "sort": "created", "direction": "desc"},
        )
        result = [
            {
                "number": p["number"],
                "title": p["title"],
                "user": p["user"]["login"],
                "created_at": p["created_at"],
                "updated_at": p["updated_at"],
                "state": p["state"],
                "draft": p.get("draft", False),
                "additions": p.get("additions", 0),
                "deletions": p.get("deletions", 0),
                "changed_files": p.get("changed_files", 0),
                "url": p["html_url"],
            }
            for p in pulls
        ]
        return jsonify(result)
    except requests.HTTPError as e:
        return jsonify({"error": str(e)}), e.response.status_code


@app.route("/api/commits")
def get_commits():
    owner = request.args.get("owner", "")
    repo = request.args.get("repo", "")
    since_days = int(request.args.get("since_days", 30))
    if not owner or not repo:
        return jsonify({"error": "owner and repo parameters required"}), 400
    try:
        since = (datetime.utcnow() - timedelta(days=since_days)).isoformat() + "Z"
        commits = gh_get_paginated(
            f"/repos/{owner}/{repo}/commits",
            {"since": since},
            max_pages=3,
        )
        result = [
            {
                "sha": c["sha"][:7],
                "message": c["commit"]["message"].split("\n")[0][:100],
                "author": c["commit"]["author"]["name"],
                "author_login": (c.get("author") or {}).get("login", ""),
                "date": c["commit"]["author"]["date"],
                "url": c["html_url"],
            }
            for c in commits
        ]
        return jsonify(result)
    except requests.HTTPError as e:
        return jsonify({"error": str(e)}), e.response.status_code


@app.route("/api/metrics")
def get_metrics():
    owner = request.args.get("owner", "")
    repo = request.args.get("repo", "")
    since_days = int(request.args.get("since_days", 30))
    if not owner or not repo:
        return jsonify({"error": "owner and repo parameters required"}), 400
    try:
        since = (datetime.utcnow() - timedelta(days=since_days)).isoformat() + "Z"
        commits = gh_get_paginated(
            f"/repos/{owner}/{repo}/commits",
            {"since": since},
            max_pages=5,
        )

        # Commits per day
        commits_by_day = defaultdict(int)
        commits_by_author = defaultdict(int)
        for c in commits:
            day = c["commit"]["author"]["date"][:10]
            commits_by_day[day] += 1
            author = (c.get("author") or {}).get("login") or c["commit"]["author"]["name"]
            commits_by_author[author] += 1

        # Fill missing days
        days = []
        counts = []
        start = datetime.utcnow() - timedelta(days=since_days)
        for i in range(since_days + 1):
            d = (start + timedelta(days=i)).strftime("%Y-%m-%d")
            days.append(d)
            counts.append(commits_by_day.get(d, 0))

        # Open vs closed issues
        open_issues = gh_get(f"/repos/{owner}/{repo}", {})
        total_open = open_issues.get("open_issues_count", 0)

        # PR stats
        open_prs = gh_get_paginated(
            f"/repos/{owner}/{repo}/pulls", {"state": "open"}, max_pages=2
        )
        closed_prs = gh_get_paginated(
            f"/repos/{owner}/{repo}/pulls",
            {"state": "closed", "sort": "updated", "direction": "desc"},
            max_pages=1,
        )

        return jsonify(
            {
                "commits_by_day": {"labels": days, "data": counts},
                "commits_by_author": {
                    "labels": list(commits_by_author.keys()),
                    "data": list(commits_by_author.values()),
                },
                "total_commits": len(commits),
                "total_open_issues": total_open,
                "open_prs": len(open_prs),
                "closed_prs": len(closed_prs),
                "active_contributors": len(commits_by_author),
            }
        )
    except requests.HTTPError as e:
        return jsonify({"error": str(e)}), e.response.status_code


@app.route("/api/export/issues")
def export_issues():
    owner = request.args.get("owner", "")
    repo = request.args.get("repo", "")
    if not owner or not repo:
        return jsonify({"error": "owner and repo parameters required"}), 400
    try:
        issues = gh_get_paginated(
            f"/repos/{owner}/{repo}/issues",
            {"state": "open", "sort": "created", "direction": "desc"},
        )
        issues = [i for i in issues if "pull_request" not in i]
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["#", "Title", "Author", "Created", "Updated", "Labels", "Comments", "URL"])
        for i in issues:
            writer.writerow([
                i["number"],
                i["title"],
                i["user"]["login"],
                i["created_at"],
                i["updated_at"],
                ", ".join(lb["name"] for lb in i.get("labels", [])),
                i["comments"],
                i["html_url"],
            ])
        output.seek(0)
        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={"Content-Disposition": f"attachment; filename={repo}_issues.csv"},
        )
    except requests.HTTPError as e:
        return jsonify({"error": str(e)}), e.response.status_code


@app.route("/api/export/commits")
def export_commits():
    owner = request.args.get("owner", "")
    repo = request.args.get("repo", "")
    since_days = int(request.args.get("since_days", 30))
    if not owner or not repo:
        return jsonify({"error": "owner and repo parameters required"}), 400
    try:
        since = (datetime.utcnow() - timedelta(days=since_days)).isoformat() + "Z"
        commits = gh_get_paginated(
            f"/repos/{owner}/{repo}/commits", {"since": since}, max_pages=3
        )
        output = io.StringIO()
        writer = csv.writer(output)
        writer.writerow(["SHA", "Message", "Author", "GitHub Login", "Date", "URL"])
        for c in commits:
            writer.writerow([
                c["sha"][:7],
                c["commit"]["message"].split("\n")[0][:100],
                c["commit"]["author"]["name"],
                (c.get("author") or {}).get("login", ""),
                c["commit"]["author"]["date"],
                c["html_url"],
            ])
        output.seek(0)
        return Response(
            output.getvalue(),
            mimetype="text/csv",
            headers={"Content-Disposition": f"attachment; filename={repo}_commits.csv"},
        )
    except requests.HTTPError as e:
        return jsonify({"error": str(e)}), e.response.status_code


if __name__ == "__main__":
    if not GITHUB_TOKEN:
        print("WARNING: GITHUB_TOKEN not set in .env — API rate limits will be very low")
    app.run(debug=True, port=5000)
